clear
close all
clc
% Two-qubit, m=2000, training 50, vary prevalence difference (imbalanceness
% of data)

dim=2;m=2000;per=50;
[data,class]=load_data(dim,m);

data_dist=[1800	37186
		2814	33000
		2814	18000
		2814	14000
		2814	10000
		2814	8000
		2814	5500
		2814	4500
		2814	3500
		2814	3000];
prevalenceDiff= abs(data_dist(:,1)-data_dist(:,2))./sum(data_dist,2);
totalSamples=sum(data_dist,2);
oa_all=zeros(10,2);
aa_all=zeros(10,2);
index1=find(class==1);index0=find(class==0);

for it=1:30
    for i=1:size(data_dist,1)
        index1=index1(randperm(numel(index1)));index0=index0(randperm(numel(index0)));
        data_class{i,1}=[data(index1(1:data_dist(i,1)),:) ; data(index0(1:data_dist(i,2)),:)];
        data_class{i,2}=[class(index1(1:data_dist(i,1)),1) ; class(index0(1:data_dist(i,2)),1)];
    end
    for i=1:size(data_class,1)
        dataPD=data_class{i,1};
        classPD=data_class{i,2};
        [oa(i,1),aa(i,1),~,~]=BCHM(dataPD,classPD,per,'BCHA');
        [oa(i,2),aa(i,2),~,~]=BCHM(dataPD,classPD,per,'RUSBCHA');
        disp(['Two-qubit: Iter=',num2str(it),': Per=',num2str(per),': m=',num2str(m),': prevalenceDiff=',num2str(prevalenceDiff(i))]);
    end
    oa_all=oa_all+oa;
    aa_all=aa_all+aa;
end
oa=oa_all./30;
aa=aa_all./30;

save preVal_aa_2X2 aa
save preVal_oa_2X2 oa
save prevalenceDiff_2X2 prevalenceDiff

load preVal_aa_2X2
load preVal_oa_2X2
load prevalenceDiff_2X2

X=repmat(prevalenceDiff',[2,1]);
figure;subplot(1,2,2);plot(X',aa,'LineWidth',2);legend('BCHA','RUSBCHA');xlim([0 1]);ylim([0.6 1]);xlabel('Prevalence Difference of Data');ylabel('Average Accuracy');title('(b)');grid on;
subplot(1,2,1);plot(X',oa,'LineWidth',2);legend('BCHA','RUSBCHA');xlim([0 1]);ylim([0.6 1]);xlabel('Prevalence Difference of Data');ylabel('Overall Accuracy');title('(a)');grid on;
