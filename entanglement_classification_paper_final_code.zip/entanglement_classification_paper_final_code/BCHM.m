function [oa,aa,Fm,Gm]=BCHM(data,class,per,type)
c=cvpartition(class,'HoldOut',1-(per/100));
train_loc=c.training;
test_loc=~train_loc;
alpha=data(:,end);
if(strcmp(type,'CHA'))
    y_fit = alpha < 1;
    y_fit = y_fit(test_loc);
    [oa, aa, ~, ~]=perf_measure(class(test_loc),y_fit);
    Eval=Evaluate(class(test_loc),y_fit);
    %disp([oa,aa,Eval(6:7)]);
elseif(strcmp(type,'BCHA'))
    B = TreeBagger(100, data(train_loc,:), class(train_loc));
    y_fit = cell2mat(predict(B, data(test_loc,:))) - 48;  %Character to Integer
    [oa, aa, ~, ~]=perf_measure(class(test_loc),y_fit);
    Eval=Evaluate(class(test_loc),y_fit);
    %disp([oa,aa,Eval(6:7)]);
elseif(strcmp(type,'RUSBCHA'))
    t = templateTree('Surrogate','on','MaxNumSplits',1);
    rusTree = fitcensemble(data(train_loc,:),class(train_loc),'Method','RUSBoost','NumLearningCycles',15,'Learners',t,'LearnRate',0.2,'Cost',[0 1;1e5 0]);
    y_fit=predict(rusTree,data(test_loc,:));
    [oa, aa, ~, ~]=perf_measure(class(test_loc),y_fit);
    Eval=Evaluate(class(test_loc),y_fit);
    %disp([oa,aa,Eval(6:7)]);
end
Fm=Eval(6);
Gm=Eval(7);
end
