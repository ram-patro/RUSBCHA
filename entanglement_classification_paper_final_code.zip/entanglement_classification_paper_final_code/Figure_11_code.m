clear
close all
clc
% Two-qutrit, m=20000, training 50, vary prevalence difference (imbalanceness
% of data)

dim=3;m=20000;per=50;
[data,class]=load_data(dim,m);

data_dist=[600	13249
           1380	13249
           2200	13249
           3200	13249
           4200	13249
           5500	13249
           6751	13000
           6751	10500
           6751	8500
           6751	7000];
        
prevalenceDiff= abs(data_dist(:,1)-data_dist(:,2))./sum(data_dist,2);
totalSamples=sum(data_dist,2);
oa_all=zeros(10,2);
aa_all=zeros(10,2);
index1=find(class==1);index0=find(class==0);

for it=1:30
    for i=1:size(data_dist,1)
        index1=index1(randperm(numel(index1)));index0=index0(randperm(numel(index0)));
        data_class{i,1}=[data(index1(1:data_dist(i,1)),:) ; data(index0(1:data_dist(i,2)),:)];
        data_class{i,2}=[class(index1(1:data_dist(i,1)),1) ; class(index0(1:data_dist(i,2)),1)];
    end
    for i=1:size(data_class,1)
        dataPD=data_class{i,1};
        classPD=data_class{i,2};
        [oa(i,1),aa(i,1),~,~]=BCHM(dataPD,classPD,per,'BCHA');
        [oa(i,2),aa(i,2),~,~]=BCHM(dataPD,classPD,per,'RUSBCHA');
        disp(['Two-qutrit: Iter=',num2str(it),': Per=',num2str(per),': m=',num2str(m),': prevalenceDiff=',num2str(prevalenceDiff(i))]);
    end
    oa_all=oa_all+oa;
    aa_all=aa_all+aa;
end
oa=oa_all./30;
aa=aa_all./30;

save preVal_aa_3X3 aa
save preVal_oa_3X3 oa
save prevalenceDiff_3X3 prevalenceDiff

load preVal_aa_3X3
load preVal_oa_3X3
load prevalenceDiff_3X3

X=repmat(prevalenceDiff',[2,1]);
figure;subplot(1,2,2);plot(X',aa,'LineWidth',2);legend('BCHA','RUSBCHA');xlim([0 1]);ylim([0.6 1]);xlabel('Prevalence Difference of Data');ylabel('Average Accuracy');title('(b)');grid on;
subplot(1,2,1);plot(X',oa,'LineWidth',2);legend('BCHA','RUSBCHA');xlim([0 1]);ylim([0.6 1]);xlabel('Prevalence Difference of Data');ylabel('Overall Accuracy');title('(a)');grid on;
