clear
close all
clc

dim=3;
if dim==2
    m=2000;
elseif dim==3
    m=20000;
end

addpath(genpath('data'));
if dim == 2
    load 2x2rdm.mat
    file_alpha 	= sprintf('qubit%d.mat', m);
else
    load 3x3rdm.mat
    file_alpha 	= sprintf('qutrit%d.mat', m);
    label=~label; %Convert label conventions to (Separable 1 and Entangled 0)
end

load(file_alpha, 'alpha');

data=[points alpha];
class=label;

if(dim==2)
    disp('Two-qubit system');
elseif(dim==3)
    disp('Two-qutrit system');
end

disp(['Percentage of separable samples = ',num2str(sum(label)/numel(label)*100),'%']);
disp(['Percentage of entangled samples = ',num2str(sum(~label)/numel(label)*100),'%']);
disp(['Prevalence difference = ',num2str(abs((sum(label)/numel(label))-(sum(~label)/numel(label))))]);
