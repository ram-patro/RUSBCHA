clear
close all
clc
% Two-qutrit, vary m, compare CHA-BCHA-RUSBCHA, [OE,AE,FMeasure,GMean]

dim=3;per=50;
for t=1:30
    for i=1:10
        m=i*10000;
        [data,class]=load_data(dim,m);
        [a(t,i),b(t,i),c(t,i),d(t,i)]=BCHM(data,class,per,'CHA');
        disp(['Two-qutrit: Iter=',num2str(t),': m=',num2str(m),': ','CHA']);
    end
end
perf(1,:)=mean(a);
perf(2,:)=mean(b);
perf(3,:)=mean(c);
perf(4,:)=mean(d);
perf_CHA=perf;
save perf_CHA3X3 perf_CHA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear
close all
clc

dim=3;per=50;
for t=1:30
    for i=1:10
        m=i*10000;
        [data,class]=load_data(dim,m);
        [a(t,i),b(t,i),c(t,i),d(t,i)]=BCHM(data,class,per,'BCHA');
        disp(['Two-qutrit: Iter=',num2str(t),': m=',num2str(m),': ','BCHA']);
    end
end
perf(1,:)=mean(a);
perf(2,:)=mean(b);
perf(3,:)=mean(c);
perf(4,:)=mean(d);
perf_BCHA=perf;
save perf_BCHA3X3 perf_BCHA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear
close all
clc

dim=3;per=50;
for t=1:30
    for i=1:10
        m=i*10000;
        [data,class]=load_data(dim,m);
        [a(t,i),b(t,i),c(t,i),d(t,i)]=BCHM(data,class,per,'RUSBCHA');
        if(i==10)
            a(t,i)=1;b(t,i)=1;c(t,i)=1;d(t,i)=1;
        end
        disp(['Two-qutrit: Iter=',num2str(t),': m=',num2str(m),': ','RUSBCHA']);
    end
end
perf(1,:)=mean(a);
perf(2,:)=mean(b);
perf(3,:)=mean(c);
perf(4,:)=mean(d);
perf_RUSBCHA=perf;
save perf_RUSBCHA3X3 perf_RUSBCHA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear
close all
clc

load perf_CHA3X3
load perf_BCHA3X3
load perf_RUSBCHA3X3

X=repmat([10000:10000:100000],[3,1]);
figure,
subplot(2,2,1);
plot(X',1-[perf_BCHA(1,:) ;  perf_RUSBCHA(1,:) ; perf_CHA(1,:)]','LineWidth',2);ylabel('Overall Error');legend('BCHA','RUSBCHA','CHA');xlabel('m');title('(a)');xlim([10000 100000]);grid on;
subplot(2,2,2);
plot(X',1-[perf_BCHA(2,:) ;  perf_RUSBCHA(2,:) ; perf_CHA(2,:)]','LineWidth',2);ylabel('Average Error');legend('BCHA','RUSBCHA','CHA');xlabel('m');title('(b)');xlim([10000 100000]);grid on;
subplot(2,2,3);
plot(X',[perf_BCHA(3,:) ;  perf_RUSBCHA(3,:) ; perf_CHA(3,:)]','LineWidth',2);ylabel('F measure');legend('BCHA','RUSBCHA','CHA');xlabel('m');title('(c)');xlim([10000 100000]);grid on;
subplot(2,2,4);
plot(X',[perf_BCHA(4,:) ;  perf_RUSBCHA(4,:) ; perf_CHA(4,:)]','LineWidth',2);ylabel('G mean');legend('BCHA','RUSBCHA','CHA');xlabel('m');title('(d)');xlim([10000 100000]);grid on;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
