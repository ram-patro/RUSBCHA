function [data,class]=load_data(dim,m)
addpath(genpath('data'));
if dim == 2
    load 2x2rdm.mat
    file_alpha 	= sprintf('qubit%d.mat', m);
elseif(dim==3)
    load 3x3rdm.mat
    file_alpha 	= sprintf('qutrit%d.mat', m);
    label=~label; %Convert label conventions to (Separable 1 and Entangled 0)
end

load(file_alpha, 'alpha');

data=[points alpha];
class=label;