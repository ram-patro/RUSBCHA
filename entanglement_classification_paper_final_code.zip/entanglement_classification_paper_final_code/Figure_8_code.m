clear
close all
clc
% Two-qubit, m=2000, vary training 10:5:50, mean over 30 iteration

dim=2;m=2000;
[data,class]=load_data(dim,m);

cnt=1;
for per=10:5:50
    for i=1:30
        [oa(i,1),aa(i,1),~,~]=BCHM(data,class,per,'BCHA');
        [oa(i,2),aa(i,2),~,~]=BCHM(data,class,per,'RUSBCHA');
        disp(['Two-qubit: Iter=',num2str(i),': Per=',num2str(per),': m=',num2str(m)]);
    end
    perf_oa_2X2(cnt,:)=[mean(oa(:,1)) mean(oa(:,2))];
    perf_aa_2X2(cnt,:)=[mean(aa(:,1)) mean(aa(:,2))];
    cnt=cnt+1;
end

save perf_aa_2X2 perf_aa_2X2
save perf_oa_2X2 perf_oa_2X2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear
close all
clc

load perf_aa_2X2
load perf_oa_2X2
X=repmat(10:5:50,[2,1]);
figure;subplot(1,2,2);plot(X',perf_aa_2X2,'LineWidth',2);legend('BCHA','RUSBCHA');xlim([10 50]);ylim([0.7 1]);xlabel('Percentage of Training Samples');ylabel('Average Accuracy');title('(b)');grid on;
subplot(1,2,1);plot(X',perf_oa_2X2,'LineWidth',2);legend('BCHA','RUSBCHA');xlim([10 50]);ylim([0.7 1]);xlabel('Percentage of Training Samples');ylabel('Overall Accuracy');title('(a)');grid on;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%