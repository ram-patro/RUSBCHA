clear
close all
clc
% Two-qubit, vary m, compare CHA-BCHA-RUSBCHA, [OE,AE,FMeasure,GMean]

dim=2;per=50;
for t=1:30
    for i=1:10
        m=i*1000;
        [data,class]=load_data(dim,m);
        [a(t,i),b(t,i),c(t,i),d(t,i)]=BCHM(data,class,per,'CHA');
        disp(['Two-qubit: Iter=',num2str(t),': m=',num2str(m),': ','CHA']);
    end
end
perf(1,:)=mean(a);
perf(2,:)=mean(b);
perf(3,:)=mean(c);
perf(4,:)=mean(d);
perf_CHA=perf;
save perf_CHA2X2 perf_CHA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear
close all
clc

dim=2;per=50;
for t=1:30
    for i=1:10
        m=i*1000;
        [data,class]=load_data(dim,m);
        [a(t,i),b(t,i),c(t,i),d(t,i)]=BCHM(data,class,per,'BCHA');
        disp(['Two-qubit: Iter=',num2str(t),': m=',num2str(m),': ','BCHA']);
    end
end
perf(1,:)=mean(a);
perf(2,:)=mean(b);
perf(3,:)=mean(c);
perf(4,:)=mean(d);
perf_BCHA=perf;
save perf_BCHA2X2 perf_BCHA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear
close all
clc

dim=2;per=50;
for t=1:30
    for i=1:10
        m=i*1000;
        [data,class]=load_data(dim,m);
        [a(t,i),b(t,i),c(t,i),d(t,i)]=BCHM(data,class,per,'RUSBCHA');
        disp(['Two-qubit: Iter=',num2str(t),': m=',num2str(m),': ','RUSBCHA']);
    end
end
perf(1,:)=mean(a);
perf(2,:)=mean(b);
perf(3,:)=mean(c);
perf(4,:)=mean(d);
perf_RUSBCHA=perf;
save perf_RUSBCHA2X2 perf_RUSBCHA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear
close all
clc

load perf_CHA2X2
load perf_BCHA2X2
load perf_RUSBCHA2X2

X=repmat([1000:1000:10000],[3,1]);
figure,
subplot(2,2,1)
plot(X',1-[perf_BCHA(1,:) ;  perf_RUSBCHA(1,:) ; perf_CHA(1,:)]','LineWidth',2);ylabel('Overall Error');legend('BCHA','RUSBCHA','CHA');xlabel('m');title('(a)');xlim([1000 10000]);grid on;
subplot(2,2,2)
plot(X',1-[perf_BCHA(2,:) ;  perf_RUSBCHA(2,:) ; perf_CHA(2,:)]','LineWidth',2);ylabel('Average Error');legend('BCHA','RUSBCHA','CHA');xlabel('m');title('(b)');xlim([1000 10000]);grid on;
subplot(2,2,3)
plot(X',[perf_BCHA(3,:) ;  perf_RUSBCHA(3,:) ; perf_CHA(3,:)]','LineWidth',2);ylabel('F measure');legend('BCHA','RUSBCHA','CHA');xlabel('m');title('(c)');xlim([1000 10000]);grid on;
subplot(2,2,4)
plot(X',[perf_BCHA(4,:) ;  perf_RUSBCHA(4,:) ; perf_CHA(4,:)]','LineWidth',2);ylabel('G mean');legend('BCHA','RUSBCHA','CHA');xlabel('m');title('(d)');xlim([1000 10000]);grid on;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%